ACE Editor noconflict packs.

These packs are copied verbatim from [ace-builds](https://github.com/ajaxorg/ace-builds). __DO NOT MODIFY__.