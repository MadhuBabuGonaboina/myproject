ace.define("ace/snippets/nix",["require","exports","module"], function(require, exports, module) {
"use strict";

exports.snippetText =undefined;
exports.scope = "nix";

});
